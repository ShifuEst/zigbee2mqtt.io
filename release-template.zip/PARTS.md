# MD-GATE-ZB1 — parts and software

One controller operates one gate installation. The same firmware supports the main and pedestrian inputs on either a Sommer twist 350 / 350 rapido or a Proteco Q80S.

## Hardware

| Quantity | Part | Requirement / purpose |
| --- | --- | --- |
| 1 | ESP32-H2 development board | 4 MB flash; GPIO10, GPIO11, GPIO13 and GPIO14 accessible. Zigbee radio built in. |
| 1 | Two-channel relay module | 5 V supply, LOW-trigger inputs explicitly compatible with 3.3 V logic, two independent voltage-free COM/NO contacts. The tested module's manufacturer/model is not confirmed. |
| 2 | 10 kΩ resistor | One from GPIO10 to 3.3 V, one from GPIO11 to 3.3 V. Keeps the inputs inactive while the MCU output is high impedance; not a 5 V level converter. |
| 1 | Regulated 5 V supply | Powers the ESP32 board's 5 V input and relay VCC. Check the exact board's power input specification. |
| As needed | 24 V to 5 V DC step-down converter | For the Sommer auxiliary supply option. Input rating must cover the measured input voltage and transients. Output must support the board and relays. The shared Sommer 35/36 output is limited to 100 mA at 24 V; verify available power including existing accessories. No particular converter model has been validated. |
| 1 | USB data cable | Programming and bench testing. |
| As needed | Wires, insulated terminals, enclosure and strain relief | Keep control wiring separated from mains wiring. |
| Optional | One or two voltage-free position contacts | Closed sensor: GPIO13–GND; open sensor: GPIO14–GND. Sommer's isolated 37/38 status contact can replace the closed sensor as described in the wiring guide. |
| 1 | Zigbee coordinator and Zigbee2MQTT server | Required for pairing and control; not part of the ESP32 board. |

The working LOW relay module was bench-tested by the owner with both outputs after repairing a cold solder joint. A generic marking such as “5 V relay” or “LOW” alone does not prove 3.3 V input compatibility. The earlier incompatible module raised its disconnected IN terminal to about 5.2 V; do not connect such an input directly to an ESP32 GPIO.

Proteco JP8 limit-switch terminals are not confirmed voltage-free isolated contacts. Do not connect them directly to GPIO13/14 or ESP32 GND. A suitable isolated sensing interface requires measurements and verification; it is not included in the validated parts list.

## Connections at the ESP32

| ESP32 | Connection |
| --- | --- |
| 5 V | Regulated 5 V and relay VCC |
| GND | Supply negative and relay GND |
| GPIO10 | Relay IN1 — main gate |
| GPIO11 | Relay IN2 — pedestrian/WALK |
| GPIO13 | Closed-position dry contact; other side to GND |
| GPIO14 | Open-position dry contact; other side to GND, only in two-sensor mode |
| 3.3 V | Each output's separate 10 kΩ pull-up |

Relay COM/NO contacts connect to the gate's button terminals, independently of the ESP32 supply. See the Sommer and Proteco diagrams for their different terminal numbers.

## Software used

- Arduino-ESP32 core 3.3.12, official Espressif Zigbee library and ESP-IDF RMT driver.
- MD-GATE-ZB1 firmware, LOW only; ESP32-H2, Zigbee router (ZCZR), 4 MB flash, `zigbee_zczr` partitions.
- Zigbee2MQTT and the MD-GATE-ZB1 converter; the external converter remains necessary until support is merged and included in the installed Zigbee2MQTT release.
- Python 3.11 or newer and esptool 5.4.0 for the portable Windows flasher.

Firmware 1.7.0-rc1 is the existing bench-tested binary and includes the 1-second post-pulse cooldown. The 1.7.0-rc2 source removes that cooldown; do not label an rc1 binary as rc2. The configured pulse duration is preserved and commands received during an active pulse are ignored.
