"""Portable ESP32-H2 flasher. --check-only does not access any serial port."""
from pathlib import Path
import hashlib, json, subprocess, sys, argparse
ROOT = Path(__file__).resolve().parent

def validate():
    m = json.loads((ROOT / "release.json").read_text(encoding="utf-8-sig"))
    v = m["variants"]["LOW"]
    image = ROOT / "MD-GATE-ZB1-LOW.bin"
    if m["chip"] != "esp32h2" or v["file"] != image.name or v["relay_type"] != "LOW":
        raise RuntimeError("Unexpected firmware manifest")
    data = image.read_bytes()
    if len(data) != 4194304 or hashlib.sha256(data).hexdigest() != v["sha256"].lower():
        raise RuntimeError("Firmware checksum/size mismatch. Nothing written.")
    return image

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    image = validate()
    if args.check_only:
        print("PASS: ESP32-H2 LOW image, 4 MB, SHA256 matches. No serial port opened.")
        return 0
    from serial.tools import list_ports
    import esptool
    ports = list(list_ports.comports())
    print("MD-GATE-ZB1 1.7.0-rc2 LOW - ESP32-H2, 4 MB only")
    print("Disconnect the gate COM/NO wires and relay inputs before flashing.")
    print("Close serial monitors. This overwrites firmware, pairing and settings.")
    print("Release candidate: new firmware requires bench verification before gate connection.")
    for i, port in enumerate(ports, 1):
        print(f"{i}: {port.device} - {port.description}")
    if not ports:
        print("No serial port. Hold BOOT while connecting USB, release and retry.")
        return 1
    choice = input("Select port number, or Enter to cancel: ").strip()
    if not choice: return 0
    if not choice.isdigit() or not 1 <= int(choice) <= len(ports):
        raise RuntimeError("Invalid port selection")
    port = ports[int(choice)-1].device
    if input(f"Type FLASH to erase and write {port}: ").strip() != "FLASH": return 0
    base = [sys.executable, "-m", "esptool", "--chip", "esp32h2", "--port", port, "--baud", "460800"]
    probe = subprocess.run(base + ["flash-id"], capture_output=True, text=True)
    print(probe.stdout); print(probe.stderr)
    if probe.returncode or "Detected flash size: 4MB" not in probe.stdout:
        raise RuntimeError("ESP32-H2 / 4 MB check failed. Nothing written.")
    result = subprocess.run(base + ["write-flash", "--erase-all", "0x0", str(image)])
    if result.returncode: raise RuntimeError("Flashing failed. Keep gate disconnected and retry.")
    print("Firmware written and verified by esptool. Press RESET if necessary.")
    print("Enable Permit join, hold BOOT for 3 seconds and release. Wait 10 seconds.")
    print("Follow README.md to install the converter and bench-test both channels.")
    return 0

if __name__ == "__main__":
    try: sys.exit(main())
    except (OSError, RuntimeError, KeyError, ValueError, ImportError) as e:
        print(f"ERROR: {e}"); sys.exit(1)
    except (KeyboardInterrupt, EOFError):
        print("Cancelled. If flashing started, rewrite the complete image before use.")
        sys.exit(1)
