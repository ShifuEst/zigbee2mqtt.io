# MD-GATE-ZB1 1.7.0-rc2 LOW

ESP32-H2 with 4 MB flash. Main gate on GPIO10, pedestrian/WALK on GPIO11.
For Sommer twist 350 / 350 rapido DTA-1 or Proteco Q80S; one ESP32 controls one gate.
LOW-trigger relay modules with explicit 3.3 V input compatibility only. No HIGH firmware.
This release removes the 1-second post-pulse cooldown. A command can run as soon as the previous pulse has finished; commands during an active pulse are ignored. Pulse duration remains configurable. This new binary requires bench verification before connection to either gate.

## Flash on Windows

1. Extract the entire ZIP to a writable folder. Do not run inside the ZIP.
2. Install Python 3.11 or newer from https://www.python.org/downloads/windows/ including the Python launcher. Administrator mode is not required.
3. Disconnect gate COM/NO wiring and relay inputs; use USB power only while flashing. Connect the ESP32-H2 by a USB data cable. Close serial monitors.
4. Run FLASH.cmd. First run needs Internet access to install esptool 5.4.0 into a local .venv folder. No Arduino compilation is needed.
5. Select the correct serial port. Type FLASH when ready. This overwrites the entire 4 MB flash including old settings and pairing. The tool verifies the image checksum, chip and flash size before writing.
6. Wait for esptool verification and the success message; do not disconnect USB during writing. Press RESET if needed.
7. Install the converter below, enable Permit join, hold BOOT for 3 seconds and release. Wait 10 seconds before testing. For an older pairing, a fresh interview/re-pair may be needed to discover the pedestrian endpoint.

No port? Hold BOOT while connecting USB, release and retry. Check the data cable. If flashing fails, keep the gate disconnected and rewrite the complete image.

Other systems: create a Python virtual environment, install requirements.txt and run `python flash.py`. To check the file without touching USB: `python flash.py --check-only`.

## Zigbee2MQTT setup

Until matching built-in support is released and installed, install md-gate-zb1.mjs once per Zigbee2MQTT server. Pairing alone does not install this file.

1. Open Settings > Dev console > External converters.
2. Create a converter named md-gate-zb1.mjs, or update that existing converter. Paste the complete included file and save; wait for converter/save OK.
3. If external JavaScript is disabled, enable enable_external_js in Settings > Advanced and restart first. Install only a converter you trust.
4. Restart Zigbee2MQTT, then pair/re-interview the device.
5. Exposes must show both main and pedestrian PRESS buttons, pulse duration and sensor mode. The included tested converter uses Estonian state labels: Kogu varav (main gate), Jalakaiguava (pedestrian), Suletud (closed), Avatud (not closed in one-sensor mode), Uks andur (one sensor), Kaks andurit (two sensors). Accented spellings appear in the UI.

Default pulse is 300 ms; zero disables pulses. There is no extra post-pulse cooldown. Commands received during an active pulse are ignored, not queued; either output can accept a new command after the pulse has finished. No ZHA compatibility is claimed.

## ESP32 and relay wiring

- Regulated 5 V to ESP32 5 V and relay VCC; supply negative to both GND pins.
- GPIO10 to IN1 (main); GPIO11 to IN2 (pedestrian).
- Each output gets its own 10 kOhm pull-up to 3.3 V. Idle HIGH, pulse LOW.
- GPIO13 closed-position dry contact to GND; GPIO14 optional open-position dry contact to GND. GPIO12 unused.
- LOW and 5 V labels alone do not prove 3.3 V input compatibility. Never feed relay 5 V into a GPIO. Pull-ups are not voltage converters.
- Use COM/NO only; leave NC unused. Do not combine USB and external 5 V power unless your board explicitly supports it.

## Sommer twist 350 / 350 rapido DTA-1

![Sommer complete wiring](images/MD-GATE-ZB1-sommer.png)

Relay COM1/NO1 to 21/22 PULSE; COM2/NO2 to 23/24 WALK. WALK operates the M2 pedestrian leaf.
Free dry status contact: 37 to GPIO13 and 38 to ESP32 GND. DIP4 ON, DIP6 OFF; leave all other DIP switches unchanged. One-sensor mode: closed contact means closed; open contact means not closed, not necessarily fully open. GPIO14 unused.
Power: 35 (+24 V) and 36 (GND) into a suitable 24-to-5 V DC/DC converter; measure 5.0 V before connecting the ESP32. The 24 V accessory output has a shared 100 mA limit including existing loads: verify the available power or use a separate regulated supply. Disconnect mains before enclosure wiring.

## Proteco Q80S

![Proteco complete wiring](images/MD-GATE-ZB1-proteco.png)

Relay COM1 and COM2 both to terminal 4 COMMON; NO1 to 1 START; NO2 to 3 PEDESTRIAN. Terminal 2 is STOP and must remain unchanged. Terminal 4 is not an instruction to connect ESP32 power GND. Use a separate regulated 5 V supply as shown.
Use separate voltage-free position contacts for GPIO13/14 as shown. The supplied board diagram labels JP8 12 common, 13 closing and 14 opening, but revisions/polarity must be checked. Existing limit switches are wired into the gate electronics and are not independent dry contacts for the ESP32: signal voltage or transients may damage GPIO and loading may affect the gate. Never connect JP8 directly to ESP32 GPIO/GND. Existing-switch monitoring needs measurements and a validated interface; it is not yet provided in this package. Keep original limit wiring intact.

## Commissioning and fault checks

With gate COM/NO wires disconnected, confirm each PRESS pulses only its own relay and returns to idle. Verify no activation during power-up, reset or pairing. Check position contacts, then connect the gate only after the checks pass. Preserve STOP, photocells and obstruction protection.
If one relay fails, disconnect power and inspect connector seating and solder joints; use a known-working channel/lead on the bench to isolate the issue. Reflashing cannot fix a cold solder joint.
Diagrams show electrical connections, not physical terminal placement. Follow printed terminal numbers and the controller's own manual.

## Source and integrity

source/MD_GATE_ZB1 contains the exact firmware source. Arduino ESP32 core 3.3.12; board ESP32-H2, 4 MB, Zigbee ZCZR, zigbee_zczr partition, DIO, USB CDC enabled, MD_RELAY_ACTIVE_HIGH=0. Recompilation is optional and is not performed by FLASH.cmd. SHA256SUMS.txt lists package file hashes; release.json retains the distinction between bench functional testing and completed hardware validation.

Manufacturer manuals:
- https://www.sommer.eu/SOMMER/Downloads/Montageanleitung/Drehtorantriebe/twist%20350%20-%20350%20rapido/twist-350-rapido_46800V001_EN.pdf
- https://www.proteco.net/sites/default/files/products-attached-manual/q80s_gb.pdf
- https://www.proteco.net/sites/default/files/products-attached-manual/pqsb02_03_06_2025_gb.pdf
